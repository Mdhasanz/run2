# fuck-asep-igprem

#Asep Premium Insta Cloning Sc Bypass Done By IRFAN

#Fu*k you asep

#command :

rm -rf fuck-asep-igprem

git clone https://github.com/XNX-XNX/fuck-asep-igprem.git

cd fuck-asep-igprem

python fuck-asep.py
